create
    definer = jegljiphjm@`%` procedure sp_get_user_by_id(IN p_id int)
BEGIN
    SELECT id, first_name, last_name, email, phone, password, language, status, privileges, created_at, last_logged_in, updated_at
    FROM user
    WHERE id = p_id;
END;

