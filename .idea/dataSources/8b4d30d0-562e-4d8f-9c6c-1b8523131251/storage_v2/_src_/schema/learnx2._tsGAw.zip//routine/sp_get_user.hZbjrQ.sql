create
    definer = jegljiphjm@`%` procedure sp_get_user(IN p_email varchar(255))
BEGIN
    SELECT id, first_name, last_name, email, phone, password, language, status, privileges, created_at, last_logged_in, updated_at
    FROM user
    WHERE email = p_email;
END;

