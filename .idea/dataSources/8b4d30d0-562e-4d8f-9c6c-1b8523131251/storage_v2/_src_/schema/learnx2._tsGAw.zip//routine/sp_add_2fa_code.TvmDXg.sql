create
    definer = jegljiphjm@`%` procedure sp_add_2fa_code(IN p_user_id int, IN p_code varchar(6),
                                                       IN p_method enum ('email', 'sms', 'phone'))
BEGIN
    -- Delete any previous 2fa_code
    DELETE FROM 2fa_code WHERE user_id = p_user_id;
    -- Create a new 2FA code
    INSERT INTO 2fa_code (user_id, code, method) VALUES (p_user_id, p_code, p_method);
END;

