create
    definer = jegljiphjm@`%` procedure sp_get_all_course_categories()
BEGIN
	SELECT cc.id, cc.name, COUNT(c.id) AS num_courses
	FROM course AS c JOIN course_category AS cc ON c.category_id = cc.id
	GROUP BY cc.id, cc.name
	ORDER BY cc.name;
END;

