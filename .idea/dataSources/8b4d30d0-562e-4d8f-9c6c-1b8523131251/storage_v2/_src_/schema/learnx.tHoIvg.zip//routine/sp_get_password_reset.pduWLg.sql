create
    definer = jegljiphjm@`%` procedure sp_get_password_reset(IN p_token varchar(255))
BEGIN
    SELECT id, email, created_at
    FROM password_reset
    WHERE token = p_token;
END;

