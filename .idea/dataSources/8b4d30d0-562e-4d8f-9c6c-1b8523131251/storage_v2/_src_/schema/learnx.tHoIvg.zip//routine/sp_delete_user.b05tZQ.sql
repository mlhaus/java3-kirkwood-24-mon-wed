create
    definer = jegljiphjm@`%` procedure sp_delete_user(IN p_id int)
BEGIN
    DELETE FROM user WHERE id = p_id;
END;

