create
    definer = jegljiphjm@`%` procedure sp_add_enrollment(IN p_user_id int, IN p_course_id int)
BEGIN
	INSERT INTO enrollment (user_id, course_id)
    VALUES (p_user_id,p_course_id);
END;

