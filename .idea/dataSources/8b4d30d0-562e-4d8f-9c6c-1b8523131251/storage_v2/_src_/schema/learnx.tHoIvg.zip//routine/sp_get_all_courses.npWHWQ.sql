create
    definer = jegljiphjm@`%` procedure sp_get_all_courses(IN p_limit int, IN p_offset int)
BEGIN
  SELECT c.id, c.name, c.description, c.level, c.picture, u.first_name, u.last_name, g.id AS category_id, g.name AS category_name
  FROM user AS u JOIN course AS c JOIN course_category AS g
  WHERE u.id = c.teacher_id AND g.id = c.category_id
  LIMIT p_limit OFFSET p_offset;
END;

