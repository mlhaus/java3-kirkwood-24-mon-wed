create
    definer = jegljiphjm@`%` procedure sp_get_courses_by_student(IN p_limit int, IN p_offset int, IN p_user_id int)
BEGIN
  SELECT c.id, c.name, c.description, c.level, c.picture, t.first_name, t.last_name, g.id AS category_id, g.name AS category_name, e.enrollment_date
  FROM user AS u JOIN enrollment AS e JOIN course AS c JOIN user AS t JOIN course_category AS g
  WHERE u.id = e.user_id
  AND c.id = e.course_id
  AND t.id = c.teacher_id
  AND g.id = c.category_id 
  AND e.user_id = p_user_id
  LIMIT p_limit OFFSET p_offset;
END;

